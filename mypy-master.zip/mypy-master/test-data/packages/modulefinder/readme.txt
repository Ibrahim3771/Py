Samples for testing modulefinder.FindModuleCache.

Contains three packages for the `nsx` namespace, and two packages
providing `a` and `b`.
